import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:datasource_core/local_db/venue_dao.dart';
import 'package:datasource_core/models/venue_item.dart';
import 'package:datasource_core/repositories/venue_repository.dart';

class MockVenueDao extends Mock implements VenueDao {}
class MockAssetBundle extends Mock implements AssetBundle {}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();

  late VenueRepository repository;
  late MockVenueDao mockDao;
  late MockAssetBundle mockBundle;

  setUp(() {
    databaseFactory = databaseFactoryFfi;

    mockDao = MockVenueDao();
    mockBundle = MockAssetBundle();

    when(() => mockBundle.loadString(any())).thenAnswer((_) async => jsonData);
    when(() => mockDao.clearVenues()).thenAnswer((_) async => {});
    when(() => mockDao.insertVenues(any())).thenAnswer((_) async => {});
    when(() => mockDao.getAllVenues()).thenAnswer((_) async => []);
    when(() => mockDao.getVenueByName(any())).thenAnswer((_) async => null);

    repository = VenueRepositoryTestable(mockDao, mockBundle);
  });

  tearDown(() => repository.dispose());

  test('getVenues returns something', () async {
    await repository.getVenues();
    verify(() => mockDao.getAllVenues()).called(greaterThan(0));
  });
}

const jsonData = '''
{
  "items": [
    {
      "name": "Test Venue",
      "city": "City",
      "location": "Loc",
      "type": "Type",
      "images": [
        { "url": "https://example.com/image.jpg" }
      ],
      "section": "Main Section",
      "coordinates": {
        "lat": 0.0,
        "lng": 0.0
      },
      "accessibleForGuestPass": false,
      "categories": [
        {
          "id": "cat_001",
          "category": "Pool",
          "details": [],
          "showOnVenuePage": true
        }
      ],
      "openingHours": {
        "Monday": "9:00 AM - 5:00 PM"
      },
      "overviewText": [
        { "text": "Overview line 1" },
        { "text": "Overview line 2" }
      ],
      "thingsToDo": [
        {
          "title": "Snorkeling Adventure",
          "badge": "Popular",
          "subtitle": "Explore the vibrant underwater life"
        }
      ]
    }
  ],
  "filters": [
    { "name": "Filter1", "value": "Value1" }
  ]
}
''';

class VenueRepositoryTestable extends VenueRepository {
  final VenueDao _mockDao;
  final AssetBundle _mockBundle;

  VenueRepositoryTestable(this._mockDao, this._mockBundle);

  @override
  VenueDao get _venueDao => _mockDao;

  @override
  Future<String> loadJson() => _mockBundle.loadString('assets/data/venues.json');
}
